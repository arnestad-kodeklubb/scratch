Scratchoppgaver fra CodeClub UK
========

Dette oppgavesettet er en oversettelse av CodeClub UK sitt
introduksjonskurs til Scratch, tilgjengelig på
https://github.com/CodeClub/scratch-curriculum.

Oppgavesettet inneholder de følgende ni oppgavene:

1. [Felix og Herbert](01-felix_og_herbert)
2. [Spøkelsesjakten](02-spokelsesjakten)
3. [Fyrverkeri](03-fyrverkeri)
4. [Enarmet banditt](04-enarmet_banditt)
5. [JafseFisk](05-jafsefisk)
6. [Ørkenløp](06-orkenlop)
7. [Hva er det?](07-hva_er_det)
8. [Tegneprogram](08-tegneprogram)
9. [Lag ditt eget spill](09-lag_ditt_eget_spill)

I tillegg er det også en ekstraoppgave:

- [Flaksefugl](11-flaksefugl)

